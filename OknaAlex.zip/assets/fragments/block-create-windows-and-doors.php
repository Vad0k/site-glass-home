<!-- БЛОК ИЗГОТОВЛЕНИЕ ОКОН И ДВЕРЕЙ -->
<aside id="block-create" class="green">
    <img src="assets/images/create-door.png" alt="изготовление дверей" class="door" />
    <img src="assets/images/create-window.png" alt="изготовление окон" class="window" />
    <h2 class="title">Изготовим любые окна и двери</h2>
    <p>Теперь вам не нужно беспокоится о доставке, мы доставим окна прямо к вашему дому.</p>
    <a href="" class="btn-white">Сделать индивидуальный заказ</a>
    <a href="">Посмотреть готовую подукцию</a>
</aside>
<!-- БЛОК ИЗГОТОВЛЕНИЕ ОКОН И ДВЕРЕЙ -->