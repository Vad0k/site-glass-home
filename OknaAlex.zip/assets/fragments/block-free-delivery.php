<!-- СЕКЦИЯ БЕСПЛАТАНЯ ДОСТАВКА -->
<aside id="block-free-delivery">
    <img src="assets/images/car.png" alt="" class="image" />
    <p class="title">Бесплатная доставка окон</p>
    <p class="description">Теперь вам не нужно беспокоится о доставке, мы доставим окна прямо к вашему дому.</p>
    <a href="" class="btn-white">Посмотреть подукцию</a>
    <a href="" class="call-me">Перезвоните мне</a>
</aside>
<!-- СЕКЦИЯ БЕСПЛАТАНЯ ДОСТАВКА -->