<!-- ГЛАВНАЯ НАВИГАЦИЯ (ШАПКА) -->
<header id="header-nav">
    <div class="logo-box">
        <div class="icon-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <img src="assets/images/logo.svg" alt="Пластиковые окна и двери" class="logo" />
        <strong>Glass House</strong>
    </div>
    <a href="tel:+79212312321" class="phone">+7 (921) 231-23-21</a>
    <nav class="nav">
        <a href="">Контакты</a>
        <a href="">Отзывы</a>
        <a href="">О Компании</a>
        <div class="item">
            <img src="assets/images/icon-header-calc.svg" alt="калькулятор синий" />
            <a href="">Калькулятор<br />стоимости</a>
        </div>
        <div class="item">
            <img src="assets/images/icon-order-size.svg" alt="метр" />
            <a href="">Вызов<br />замерщика</a>
        </div>
    </nav>
    <nav class="nav-bar">
        <div class="panel-title">
            <img src="assets/images/logo.svg" alt="логотип" /><span>Glass House</span>
        </div>
        <div class="icon-open">
            <span></span>
            <span></span>
        </div>
        <ol>
            <li><a href="">Главная</a></li>
            <li>
                <div class="icon-open icon-close">
                    <span></span>
                    <span></span>
                </div>
                <span>Окна</span>
                <ol>
                    <li><a href="">Окна</a></li>
                    <li><a href="">Окна</a></li>
                    <li><a href="">Окна</a></li>
                </ol>
            </li>
            <li>
                <div class="icon-open icon-close">
                    <span></span>
                    <span></span>
                </div>
                <span>Двери</span>
                <ol>
                    <li><a href="">Двери</a></li>
                    <li><a href="">Двери</a></li>
                    <li>
                        <div class="icon-open icon-close">
                            <span></span>
                            <span></span>
                        </div>
                        <span>LuckyFox</span>
                        <ol>
                            <li><a href="">LuckyFox</a></li>
                            <li><a href="">LuckyFox</a></li>
                            <li><a href="">LuckyFox</a></li>
                        </ol>

                    </li>
                </ol>
            </li>
            <li><a href="">Цены</a></li>
            <li><a href="">Дополнительные услуги</a></li>
            <li><a href="">Полезно знать</a></li>
            <li><a href="">О компании</a></li>
        </ol>
    </nav>
</header>


<style>
    #header-nav{
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        padding: 70px 0 53px;
        line-height: 36px;
    }
    #header-nav .logo-box{
        font-size: 0;
        margin-left: 63px;
        -webkit-flex: 1;
        -moz-flex: 1;
        flex: 1;
    }
    #header-nav .logo-box .icon-menu{
        display: inline-block;
        width: 18px;
        vertical-align: middle;
        cursor: pointer;
    }
    #header-nav .logo-box strong{
        display: inline-block;
        font-family: "Source Sans Pro Bold", Arial;
        font-size: 23px;
        color: #1FC0F2;
        vertical-align: middle;
    }
    #header-nav .logo-box .logo{
        display: inline-block;
        margin: 0 6px 0 25px;
        vertical-align: middle;
    }
    #header-nav .icon-menu span{
        display: block;
        border-bottom: 2px solid #3B5259;
        margin-bottom: 4px;
    }
    #header-nav .icon-menu span:last-child{
        margin: 0;
    }
    #header-nav .phone{
        display: inline-block;
        vertical-align: middle;
        font-family: "Source Sans Pro Bold", Arial;
        font-size: 18px;
        color: #3B5259;
        text-decoration: none;
        -webkit-transition: color .3s ease;
        -moz-transition: color .3s ease;
        -ms-transition: color .3s ease;
        -o-transition: color .3s ease;
        transition: color .3s ease;
    }
    #header-nav .phone:hover{
        color: #1FC0F2;
    }
    #header-nav .nav{
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        -webkit-align-items: center;
        -moz-align-items: center;
        align-items: center;
    }
    #header-nav .nav a{
        display: block;
        color: #3B5259;
        font-family: "Source Sans Pro Regular", Arial;
        font-size: 14px;
        text-decoration: none;
    }
    #header-nav .nav a:hover{
        text-decoration: underline;
    }
    #header-nav .nav > a{
        margin-left: 45px;
    }
    #header-nav .nav .item{
        line-height: normal;
        margin-left: 71px;
    }
    #header-nav .nav .item:last-child{
        margin-right: 63px;
    }
    #header-nav .nav .item img{
        display: inline-block;
        height: 28px;
        vertical-align: middle;
    }
    #header-nav .nav .item a{
        display: inline-block;
        margin-left: 15px;
        vertical-align: middle;
    }


    #header-nav .nav-bar{
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 950;
        color: #FFF;
        font-family: "Source Sans Pro Regular", Arial;
        font-size: 18px;
        line-height: normal;
        -webkit-transition: transform .3s ease, opacity .3s ease;
        -moz-transition: transform .3s ease, opacity .3s ease;
        -ms-transition: transform .3s ease, opacity .3s ease;
        -o-transition: transform .3s ease, opacity .3s ease;
        transition: transform .3s ease, opacity .3s ease;
        background-color: rgba(0,0,0,.5);
        -webkit-transform: rotateY(90deg);
        -moz-transform: rotateY(90deg);
        -ms-transform: rotateY(90deg);
        -o-transform: rotateY(90deg);
        transform: rotateY(90deg);
        -webkit-transform-origin: left center;
        -moz-transform-origin: left center;
        -ms-transform-origin: left center;
        -o-transform-origin: left center;
        transform-origin: left center;
    }
    #header-nav .nav-bar ol{
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        padding: 159px 84px 82px 84px;
        background-color: #1D2057;
        max-width: 394px;
        width: 100%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        -webkit-transition: transform .3s ease, opacity .3s ease;
        -moz-transition: transform .3s ease, opacity .3s ease;
        -ms-transition: transform .3s ease, opacity .3s ease;
        -o-transition: transform .3s ease, opacity .3s ease;
        transition: transform .3s ease, opacity .3s ease;
        -webkit-transform-origin: left center;
        -moz-transform-origin: left center;
        -ms-transform-origin: left center;
        -o-transform-origin: left center;
        transform-origin: left center;
    }
    #header-nav .nav-bar ol ol{
        background-color: #14153D;
        margin-left: 100%;
        opacity: 0;
        -webkit-transform: rotateY(90deg);
        -moz-transform: rotateY(90deg);
        -ms-transform: rotateY(90deg);
        -o-transform: rotateY(90deg);
        transform: rotateY(90deg);
    }
    #header-nav .nav-bar ol ol ol{
        background-color: #10112f;
    }
    #header-nav .nav-bar ol li.active > ol{
        opacity: 1;
        -webkit-transform: rotateY(0deg);
        -moz-transform: rotateY(0deg);
        -ms-transform: rotateY(0deg);
        -o-transform: rotateY(0deg);
        transform: rotateY(0deg);
    }
    #header-nav .nav-bar ol li{
        margin-bottom: 28px;
        text-transform: uppercase;
    }
    #header-nav .nav-bar ol li > span{
        -webkit-transition: color .3s ease;
        -moz-transition: color .3s ease;
        -ms-transition: color .3s ease;
        -o-transition: color .3s ease;
        transition: color .3s ease;
    }
    #header-nav .nav-bar ol li > span:hover,
    #header-nav .nav-bar ol li.active > span,
    #header-nav .nav-bar ol a:hover{
        color: #FE9545;
        cursor: pointer;
    }
    #header-nav .nav-bar ol li.active > span{
        font-family: "Source Sans Pro SemiBold", Arial;
    }
    #header-nav .nav-bar ol li > span:after{
        content: '';
        display: inline-block;
        margin-left: 15px;
        width: 6px;
        height: 10px;
        background: url('assets/images/nav-arrow-right-open.svg') no-repeat center center;
    }
    #header-nav .nav-bar ol li > span.close:after{
        content: '';
        display: inline-block;
        width: 6px;
        height: 10px;
        background: url('assets/images/nav-arrow-right-open.svg') no-repeat center center;
    }
    #header-nav .nav-bar ol li > span:hover:after{
        background: url('assets/images/nav-arrow-right-open-hover.svg') no-repeat center center;
        -webkit-transition: background .3s ease;
        -moz-transition: background .3s ease;
        -ms-transition: background .3s ease;
        -o-transition: background .3s ease;
        transition: background .3s ease;
    }
    #header-nav .nav-bar ol li.active > span:after{
        content: '';
        display: inline-block;
        width: 14px;
        height: 9px;
        background: url('assets/images/nav-arrow-right-close.svg') no-repeat center center;
    }
    #header-nav .nav-bar ol li:last-child{
        margin-bottom: 0;
    }
    #header-nav .nav-bar ol a{
        color: #FFF;
        text-decoration: none;
        -webkit-transition: color .3s ease;
        -moz-transition: color .3s ease;
        -ms-transition: color .3s ease;
        -o-transition: color .3s ease;
        transition: color .3s ease;
    }


    #header-nav .panel-title{
        display: inline-block;
        position: relative;
        top: 74px;
        left: 84px;
        z-index: 1;
        font-family: "Source Sans Pro Bold",Arial;
        font-size: 23px;
    }
    #header-nav .panel-title img{
        margin-right: 6px;
    }
    #header-nav .nav-bar .icon-open{
        position: absolute;
        top: 79px;
        left: 307px;
        bottom: 0;
        width: 18px;
        height: 18px;
        -webkit-transform: rotate(45deg);
        -moz-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        -o-transform: rotate(45deg);
        transform: rotate(45deg);
        z-index: 1;
        cursor: pointer;
    }
    #header-nav .nav-bar .icon-open > span{
        position: absolute;
        display: block;
        top:0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: auto;
        height: 2px;
        background-color: #fff;
        z-index: 1;
        -webkit-transition: all .3s ease;
        -moz-transition: all .3s ease;
        -ms-transition: all .3s ease;
        -o-transition: all .3s ease;
        transition: all .3s ease;
    }
    #header-nav .nav-bar .icon-open > span:nth-child(2){
        -webkit-transform: rotate(90deg);
        -moz-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        -o-transform: rotate(90deg);
        transform: rotate(90deg);
    }
    #header-nav .nav-bar .icon-open:hover > span{
        background-color: #FE9545;
    }
    #header-nav .nav-bar .icon-close{
        -webkit-transform: rotate(0deg);
        -moz-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        -o-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    #header-nav .nav-bar .icon-close > span:nth-child(2){
        -webkit-transform: rotate(0deg);
        -moz-transform: rotate(0deg);
        -ms-transform: rotate(0deg);
        -o-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    #header-nav .nav-bar ol .icon-close,
    #header-nav .nav-bar ol .icon-open{
        position: absolute;
        right: 0;
        margin-left: 100%;
        top: 79px;
        width: 18px;
        height: 18px;
        z-index: 2;
        cursor: pointer;
    }

    #header-nav .transform-open{
        -webkit-transition: all 1s ease;
        -moz-transition: all 1s ease;
        -ms-transition: all 1s ease;
        -o-transition: all 1s ease;
        transition: all 1s ease;

        -webkit-transform: rotateY(0deg);
        -moz-transform: rotateY(0deg);
        -ms-transform: rotateY(0deg);
        -o-transform: rotateY(0deg);
        transform: rotateY(0deg);
    }

</style>

<script>
    window.onload = function(){

        $('#header-nav .logo-box .icon-menu').click(function(){
            $('#header-nav .nav-bar').addClass('transform-open');
        });
        $(document).on('click', '#header-nav .nav-bar .icon-open', function(){
            $(this).parent().removeClass('active');
        });

        $('#header-nav .nav-bar ol li > span').click(function(){
            if($(this).parent().hasClass('active')){
                $(this).parent().removeClass('active');
            }else{
                $(this).parent().addClass('active');
            }

        });

    }
</script>

<!-- ГЛАВНАЯ НАВИГАЦИЯ (ШАПКА) -->